#!/bin/bash -v

brew update
brew install boost miniupnpc openssl berkeley-db4 protobuf || true

